Attached are input files (abmI*.txt) and one of the output files (abmRz.txt). They correspond to Fig. 5b4 in the paper. The format of the file is as follows:

t, is1, iz, on(is1,iz), oc(is1,iz), ocv(is1,iz), ou(is1,iz)
...
3046.0000    14     8     0  .000E+00  .000E+00  .000E+00
 3046.0000    14     9     0  .000E+00  .000E+00  .000E+00
 3046.0000    14    10     0  .000E+00  .000E+00  .000E+00
 3046.0000    15     1    30  .310E+10  .462E+08  .000E+00
 3046.0000    15     2    28  .462E+10  .152E+10  .000E+00
 3046.0000    15     3    29  .594E+10  .317E+10  .000E+00
 3046.0000    15     4    35  .170E+11  .134E+11  .000E+00
 3046.0000    15     5    30  .113E+11  .995E+10  .000E+00
 3046.0000    15     6    14  .105E+08  .105E+08  .000E+00
 3046.0000    15     7     0  .000E+00  .000E+00  .000E+00
 3046.0000    15     8     0  .000E+00  .000E+00  .000E+00
 3046.0000    15     9     0  .000E+00  .000E+00  .000E+00
...

The ocv value is what is plotted in the figure. Specifically, the figure shows the average concentration for the last 365 days for each layer (iz) of the winner. In this case, species (is1) 15 won, which is different from what is shown in Fig. 5b4 in the paper. Units are converted with / 1000000# / 10000# and 0 is replaced with 0.05.
